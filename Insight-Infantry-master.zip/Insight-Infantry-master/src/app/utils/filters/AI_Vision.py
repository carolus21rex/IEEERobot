def modify_image(image):
    return image

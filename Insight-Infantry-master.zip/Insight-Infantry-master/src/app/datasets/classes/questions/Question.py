def randomQuestion():
    pass
